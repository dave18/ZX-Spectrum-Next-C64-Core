-- ZPU
--
-- Copyright 2004-2008 oharboe - �yvind Harboe - oyvind.harboe@zylin.com
-- Modified by Alastair M. Robinson for the ZPUFlex project.
--
-- The FreeBSD license
-- 
-- Redistribution and use in source and binary forms, with or without
-- modification, are permitted provided that the following conditions
-- are met:
-- 
-- 1. Redistributions of source code must retain the above copyright
--    notice, this list of conditions and the following disclaimer.
-- 2. Redistributions in binary form must reproduce the above
--    copyright notice, this list of conditions and the following
--    disclaimer in the documentation and/or other materials
--    provided with the distribution.
-- 
-- THIS SOFTWARE IS PROVIDED BY THE ZPU PROJECT ``AS IS'' AND ANY
-- EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
-- PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
-- ZPU PROJECT OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
-- INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
-- (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
-- OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
-- HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
-- STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
-- ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
-- ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
-- 
-- The views and conclusions contained in the software and documentation
-- are those of the authors and should not be interpreted as representing
-- official policies, either expressed or implied, of the ZPU Project.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


library work;
use work.zpupkg.all;

entity CtrlROM_ROM is
generic
	(
		maxAddrBitBRAM : integer := maxAddrBitBRAMLimit -- Specify your actual ROM size to save LEs and unnecessary block RAM usage.
	);
port (
	clk : in std_logic;
	areset : in std_logic := '0';
	from_zpu : in ZPU_ToROM;
	to_zpu : out ZPU_FromROM
);
end CtrlROM_ROM;

architecture arch of CtrlROM_ROM is

type ram_type is array(natural range 0 to ((2**(maxAddrBitBRAM+1))/4)-1) of std_logic_vector(wordSize-1 downto 0);

shared variable ram : ram_type :=
(
     0 => x"0b0b0b0b",
     1 => x"8c0b0b0b",
     2 => x"0b81e004",
     3 => x"0b0b0b0b",
     4 => x"8c04ff0d",
     5 => x"80040400",
     6 => x"00000016",
     7 => x"00000000",
     8 => x"0b0b0b88",
     9 => x"90080b0b",
    10 => x"0b889408",
    11 => x"0b0b0b88",
    12 => x"98080b0b",
    13 => x"0b0b9808",
    14 => x"2d0b0b0b",
    15 => x"88980c0b",
    16 => x"0b0b8894",
    17 => x"0c0b0b0b",
    18 => x"88900c04",
    19 => x"00000000",
    20 => x"00000000",
    21 => x"00000000",
    22 => x"00000000",
    23 => x"00000000",
    24 => x"71fd0608",
    25 => x"72830609",
    26 => x"81058205",
    27 => x"832b2a83",
    28 => x"ffff0652",
    29 => x"0471fc06",
    30 => x"08728306",
    31 => x"09810583",
    32 => x"05101010",
    33 => x"2a81ff06",
    34 => x"520471fd",
    35 => x"060883ff",
    36 => x"ff738306",
    37 => x"09810582",
    38 => x"05832b2b",
    39 => x"09067383",
    40 => x"ffff0673",
    41 => x"83060981",
    42 => x"05820583",
    43 => x"2b0b2b07",
    44 => x"72fc060c",
    45 => x"51510471",
    46 => x"fc06080b",
    47 => x"0b0b86fc",
    48 => x"73830610",
    49 => x"10050806",
    50 => x"7381ff06",
    51 => x"73830609",
    52 => x"81058305",
    53 => x"1010102b",
    54 => x"0772fc06",
    55 => x"0c515104",
    56 => x"8890708a",
    57 => x"a4278b38",
    58 => x"80717084",
    59 => x"05530c81",
    60 => x"e2048c51",
    61 => x"86db04f6",
    62 => x"84088890",
    63 => x"0c04888c",
    64 => x"0888900c",
    65 => x"0402fc05",
    66 => x"0d807088",
    67 => x"8c0c70f6",
    68 => x"800c8890",
    69 => x"0c028405",
    70 => x"0d0402f4",
    71 => x"050d7453",
    72 => x"81fe2d88",
    73 => x"9008810a",
    74 => x"07707407",
    75 => x"52527588",
    76 => x"38720970",
    77 => x"73065151",
    78 => x"70888c0c",
    79 => x"70f6800c",
    80 => x"028c050d",
    81 => x"0402f805",
    82 => x"0d028e05",
    83 => x"80e02d51",
    84 => x"81fe2d88",
    85 => x"9008f480",
    86 => x"80067107",
    87 => x"70f6800c",
    88 => x"70888080",
    89 => x"0770888c",
    90 => x"0cf6800c",
    91 => x"5281f72d",
    92 => x"800b8890",
    93 => x"0824a238",
    94 => x"88900891",
    95 => x"2a708106",
    96 => x"51517080",
    97 => x"2ee73871",
    98 => x"888c0c71",
    99 => x"f6800c81",
   100 => x"f72d8890",
   101 => x"08802586",
   102 => x"38805183",
   103 => x"b3048890",
   104 => x"08912a70",
   105 => x"81065151",
   106 => x"70e53888",
   107 => x"900883ff",
   108 => x"ff065170",
   109 => x"88900c02",
   110 => x"88050d04",
   111 => x"02ec050d",
   112 => x"88880883",
   113 => x"06537286",
   114 => x"38830b88",
   115 => x"880c80f0",
   116 => x"80800b88",
   117 => x"88087081",
   118 => x"06555555",
   119 => x"72802e85",
   120 => x"38b0800a",
   121 => x"5573812a",
   122 => x"70810651",
   123 => x"5372802e",
   124 => x"873874ef",
   125 => x"ff0a0655",
   126 => x"81527451",
   127 => x"829a2d02",
   128 => x"94050d04",
   129 => x"02f8050d",
   130 => x"805280f0",
   131 => x"80805182",
   132 => x"9a2d0288",
   133 => x"050d0402",
   134 => x"f8050d81",
   135 => x"5290800a",
   136 => x"51829a2d",
   137 => x"0288050d",
   138 => x"0402f805",
   139 => x"0d805290",
   140 => x"800a5182",
   141 => x"9a2d0288",
   142 => x"050d0402",
   143 => x"f8050d02",
   144 => x"8f0580f5",
   145 => x"2d5283bc",
   146 => x"2d715182",
   147 => x"c52d0288",
   148 => x"050d0402",
   149 => x"fc050d02",
   150 => x"8b0580f5",
   151 => x"2d5184bb",
   152 => x"2d84842d",
   153 => x"0284050d",
   154 => x"0402f805",
   155 => x"0d028e05",
   156 => x"80e02d52",
   157 => x"84972d71",
   158 => x"5182c52d",
   159 => x"88900883",
   160 => x"ffff0688",
   161 => x"900c0288",
   162 => x"050d0402",
   163 => x"f0050d75",
   164 => x"77535377",
   165 => x"802eb438",
   166 => x"7272812a",
   167 => x"ff055454",
   168 => x"72ff2e93",
   169 => x"38737082",
   170 => x"055580e0",
   171 => x"2d5182c5",
   172 => x"2dff1353",
   173 => x"85a00471",
   174 => x"81065271",
   175 => x"802ea338",
   176 => x"7380f52d",
   177 => x"5182c52d",
   178 => x"85e204ff",
   179 => x"125271ff",
   180 => x"2e903872",
   181 => x"70810554",
   182 => x"80f52d51",
   183 => x"82c52d85",
   184 => x"cb040290",
   185 => x"050d0402",
   186 => x"ec050d80",
   187 => x"5574a007",
   188 => x"7081ff06",
   189 => x"525484bb",
   190 => x"2d805382",
   191 => x"805288a0",
   192 => x"51858b2d",
   193 => x"84842d81",
   194 => x"15558875",
   195 => x"24df3880",
   196 => x"0b8aa00c",
   197 => x"0294050d",
   198 => x"0402f405",
   199 => x"0d945184",
   200 => x"e92d8053",
   201 => x"805182c5",
   202 => x"2d889008",
   203 => x"81ff0652",
   204 => x"71802e94",
   205 => x"38710b0b",
   206 => x"0b878c14",
   207 => x"81b72d81",
   208 => x"135380fa",
   209 => x"7327dd38",
   210 => x"800b0b0b",
   211 => x"0b878c14",
   212 => x"81b72d84",
   213 => x"a92d028c",
   214 => x"050d0402",
   215 => x"fc050d82",
   216 => x"852d8699",
   217 => x"2d80c151",
   218 => x"84d32dff",
   219 => x"0b8aa00c",
   220 => x"ff0b8aa0",
   221 => x"0c85e72d",
   222 => x"86f00400",
   223 => x"00ffffff",
   224 => x"ff00ffff",
   225 => x"ffff00ff",
   226 => x"ffffff00",
   227 => x"00000000",
   228 => x"00000000",
   229 => x"00000000",
   230 => x"00000000",
   231 => x"00000000",
   232 => x"00000000",
   233 => x"00000000",
   234 => x"00000000",
   235 => x"00000000",
   236 => x"00000000",
   237 => x"00000000",
   238 => x"00000000",
   239 => x"00000000",
   240 => x"00000000",
   241 => x"00000000",
   242 => x"00000000",
   243 => x"00000000",
   244 => x"00000000",
   245 => x"00000000",
   246 => x"00000000",
   247 => x"00000000",
   248 => x"00000000",
   249 => x"00000000",
   250 => x"00000000",
   251 => x"00000000",
   252 => x"00000000",
   253 => x"00000000",
   254 => x"00000000",
   255 => x"00000000",
   256 => x"00000000",
   257 => x"00000000",
   258 => x"00000003",
   259 => x"00000000",
	others => x"00000000"
);

begin

process (clk)
begin
	if (clk'event and clk = '1') then
		if (from_zpu.memAWriteEnable = '1') and (from_zpu.memBWriteEnable = '1') and (from_zpu.memAAddr=from_zpu.memBAddr) and (from_zpu.memAWrite/=from_zpu.memBWrite) then
			report "write collision" severity failure;
		end if;
	
		if (from_zpu.memAWriteEnable = '1') then
			ram(to_integer(unsigned(from_zpu.memAAddr(maxAddrBitBRAM downto 2)))) := from_zpu.memAWrite;
			to_zpu.memARead <= from_zpu.memAWrite;
		else
			to_zpu.memARead <= ram(to_integer(unsigned(from_zpu.memAAddr(maxAddrBitBRAM downto 2))));
		end if;
	end if;
end process;

process (clk)
begin
	if (clk'event and clk = '1') then
		if (from_zpu.memBWriteEnable = '1') then
			ram(to_integer(unsigned(from_zpu.memBAddr(maxAddrBitBRAM downto 2)))) := from_zpu.memBWrite;
			to_zpu.memBRead <= from_zpu.memBWrite;
		else
			to_zpu.memBRead <= ram(to_integer(unsigned(from_zpu.memBAddr(maxAddrBitBRAM downto 2))));
		end if;
	end if;
end process;


end arch;

